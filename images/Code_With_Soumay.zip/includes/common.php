<?php
$con = mysqli_connect("localhost","root","","online_learning_platform") or die(mysqli_error($con));
session_start();
?>
